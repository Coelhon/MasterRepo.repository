import xbmcaddon
import base64

MainBase = 'aHR0cDovL2NodWNoYW5vZGVkby5ibG9nc3BvdC5jb20vYWRkb24='.decode('base64')
addon = xbmcaddon.Addon('plugin.video.frenchdj.media.center')